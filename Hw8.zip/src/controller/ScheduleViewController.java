package controller;

import controller.command.AddCalendar;
import controller.command.Command;
import controller.command.CreateEvent;
import controller.command.ModifyEvent;
import controller.command.RemoveEvent;
import controller.command.SaveCalendars;
import controller.command.ScheduleEvent;
import controller.command.SelectUser;
import plannersystem.PlannerSystem;
import schedule.Event;
import schedule.ReadOnlyEvent;
import view.EventView;
import view.EventViewImpl;
import view.PlannerSystemView;
import view.ScheduleEventView;

/**
 * Controller class for managing user actions and mouse events in the Planner System application.
 * This class listens for actions performed on the GUI and responds to mouse clicks on the schedule
 * panel.
 * It bridges the interaction between the view ({@link PlannerSystemView}) and the model
 * ({@link PlannerSystem}).
 */
public class ScheduleViewController implements PlannerSystemController {

  private final PlannerSystemView view;
  private PlannerSystem model;

  private EventView eventView;

  /**
   * Constructs a ScheduleViewController with a specified view.
   * Initializes the controller, sets itself as the listener for action and mouse events.
   *
   * @param view The {@link PlannerSystemView} for this controller to manage.
   * @throws IllegalArgumentException if the provided view is null.
   */
  public ScheduleViewController(PlannerSystemView view) {
    if (view == null) {
      throw new IllegalArgumentException("View cannot be null");
    }
    this.view = view;
    this.view.setActionListener(this);
  }

  @Override
  public void launch(PlannerSystem model) {
    this.setModel(model);
    this.view.makeVisible();
  }

  @Override
  public void processButtonPress(String action) {
    String currentUser = this.view.getCurrentUser();
    assert currentUser != null;
    Command command;
    switch (action) {
      case "Open Event Frame":
        command = null;
        this.launchEventView(currentUser, new Event(), "Standard");
        break;
      case "Open Schedule Event Frame":
        command = null;
        this.launchEventView(currentUser, new Event(), "Schedule");
        break;
      case "Add calendar":
        command = new AddCalendar(view, model);
        break;
      case "Save calendars":
        command = new SaveCalendars(currentUser, view, model);
        break;
      case "Select user":
        command = new SelectUser(currentUser, view);
        break;
      case "Create event":
        command = new CreateEvent(currentUser, model, eventView, eventView.getEvent());
        break;
      case "Modify event":
        command = new ModifyEvent(currentUser, model, eventView, eventView.getEvent());
        break;
      case "Remove event":
        command = new RemoveEvent(currentUser, model, eventView, eventView.getEvent());
        break;
      case "Schedule event":
        command = new ScheduleEvent(currentUser, model, eventView, eventView.getEvent());
        break;
      default:
        command = null;
    }

    if (command != null) {
      try {
        command.execute();
      } catch (Exception ise) {
        this.view.displayErrorMessage(ise.getMessage());
      }
    }
    this.view.refresh();
  }

  @Override
  public void processMouseClick(ReadOnlyEvent event) {
    String userId = this.view.getCurrentUser();
    this.launchEventView(userId, event, "Standard");
  }

  @Override
  public void setEventView(EventView view) {
    this.eventView = view;
  }

  @Override
  public void update() {
    this.view.updateUsers();
    this.view.refresh();
  }

  /**
   * Sets the model for this controller.
   *
   * @param model The {@link PlannerSystem} model to be set.
   * @throws IllegalArgumentException if the provided model is null.
   */
  private void setModel(PlannerSystem model) {
    if (model == null) {
      throw new IllegalArgumentException("Planner System Model is null");
    }
    this.model = model;
    this.model.addObserver(this);
  }

  /**
   * Launches an event view based on the specified user ID, event, and frame type. Displays an error
   * message if an event frame is already open or if the user selected is "none".
   *
   * @param userId    The ID of the user associated with the event view.
   * @param event     The event to be displayed in the event view.
   * @param frameType The type of frame to be launched ("Schedule" or any other value).
   */
  private void launchEventView(String userId, ReadOnlyEvent event, String frameType) {
    if (eventView != null && eventView.isViewVisible()) {
      view.displayErrorMessage("An event frame is already open.");
      return;
    }
    if (userId.equals("<none>")) {
      view.displayErrorMessage("No user is selected.");
      return;
    }
    if (frameType.equals("Schedule")) {
      this.eventView = new ScheduleEventView(event, userId);
    }
    else {
      this.eventView = new EventViewImpl(event, userId);
    }
    this.eventView.setActionListener(this);
    this.eventView.makeVisible();
  }
}
